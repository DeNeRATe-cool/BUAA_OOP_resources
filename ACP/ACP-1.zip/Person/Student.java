package Person;

import Course.Course;

import java.util.ArrayList;
import java.util.List;

public class Student extends Person {
    private List<Course> courses = new ArrayList<>();

    public Student() {}
    public Student(String id, String name, String password, String type) {
        super(id, name, password, type);
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void removeCourse(String course) {
        for(Course c : courses) {
            if(c.getId() == Integer.valueOf(course.substring(2))) {
                courses.remove(c);
                break;
            }
        }
    }

    public List<Course> getCourses() {
        return courses;
    }
}
