package Executor;

import Course.Course;
import Database.Database;
import Tool.Checker;
import Tool.CommonMethod;

public class TeacherExecutor {
    /**
     * only Teacher can create course
     * @param args command data
     * */
    public static boolean createCourse(String[] args) {
        if(!Database.checkAnyOnline() ||
            Database.notTeacher(Database.currentUser) ||
            !Database.teachers.get(Database.currentUser).checkCourseCount() ||
            !Checker.checkCourseName(args[1]) ||
            Database.teachers.get(Database.currentUser).checkCourseExistence(args[1]) ||
            !Checker.checkCourseTime(args) ||
            Checker.checkTeacherTimeConflict(args) ||
            !Checker.checkCourseScore(args[3]) ||
            !Checker.checkCourseHour(args[4])) return false;

        // Test
//        System.out.println("你成功通过了创建课程要求");

        Course course = new Course(args[1], CommonMethod.getWeekday(args[2]), CommonMethod.courseTime2Pair(args[2]), Double.parseDouble(args[3]), Integer.parseInt(args[4]));
        Course.insertCourse(course);

        Database.teachers.get(Database.currentUser).addCourse(course);

        System.out.println("Create course success (courseId: C-" + course.getId() + ")");

        return true;
    }
}
